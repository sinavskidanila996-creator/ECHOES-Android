# ECHOES: Последний мир — Android build project

## Что внутри
- Android WebView-оболочка для запуска игры как APK.
- `app/src/main/assets/www/index.html` — автономная браузерная версия игры.
- `app/src/main/assets/www/assets/sprites/player.png` — игровой спрайт-лист персонажа.
- `artwork/location_backgrounds/` — фоны: Зачарованный лес, Кристальная пещера, Древние руины.
- `artwork/enemies/` — спрайты врагов.
- `artwork/player_animation_reference_sheet.png` — исходный лист персонажа, присланный пользователем. Из него нарезаны прозрачные кадры IDLE (6), WALK (7), RUN (8), JUMP (8), ATTACK 1 (8) в `artwork/player_frames/`; игровой атлас 8×5 кадров подключён к браузерной версии и Android WebView.
- `artwork/shop_inventory_reference.png` и `artwork/boss_reference.png` — исходные изображения магазина и босса, присланные пользователем.

## Как получить APK без компьютера
1. Загрузи **всё содержимое архива** в корень GitHub-репозитория `ECHOES`, сохраняя папки.
2. Открой вкладку **Actions** в репозитории.
3. Выбери workflow **Build ECHOES APK** и нажми **Run workflow** (или дождись автоматической сборки после push).
4. Открой завершённый запуск workflow.
5. Внизу страницы найди **Artifacts** → `ECHOES-debug-APK` и скачай ZIP.
6. Распакуй ZIP — внутри будет `app-debug.apk`. Установи его на Android.

GitHub Pages публикует веб-версию, а APK собирается отдельным workflow GitHub Actions.

## Важно для GitHub
В корне проекта также лежит `index.html` — это версия для GitHub Pages. Для сборки APK в репозиторий нужно загрузить не ZIP-файл, а содержимое этой папки: `settings.gradle`, `build.gradle`, `gradle.properties`, папку `app/`, папку `.github/` и остальные файлы проекта. После загрузки GitHub Actions сможет запустить workflow.
